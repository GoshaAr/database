from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from sqlmodel import select
from typing import List, Optional
from datetime import datetime
import os, shutil, uuid

from .database import init_db, get_session
from .models import Patient, Doctor, Room, Appointment, FileAsset
from sqlmodel import Session

app = FastAPI(title="Dental Practice API")

# CORS: Adjust for production!
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "backend/storage")
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.on_event("startup")
def on_startup():
    init_db()

# ---------- Patients ----------
@app.post("/patients", response_model=Patient)
def create_patient(patient: Patient, session: Session = Depends(get_session)):
    session.add(patient)
    session.commit()
    session.refresh(patient)
    return patient

@app.get("/patients", response_model=List[Patient])
def list_patients(q: Optional[str] = None, session: Session = Depends(get_session)):
    statement = select(Patient)
    patients = session.exec(statement).all()
    if q:
        ql = q.lower()
        patients = [p for p in patients if ql in (p.first_name + " " + p.last_name).lower()]
    return patients

@app.get("/patients/{patient_id}", response_model=Patient)
def get_patient(patient_id: int, session: Session = Depends(get_session)):
    patient = session.get(Patient, patient_id)
    if not patient:
        raise HTTPException(404, "Patient not found")
    return patient

# ---------- Doctors & Rooms ----------
@app.get("/doctors", response_model=List[Doctor])
def list_doctors(session: Session = Depends(get_session)):
    return session.exec(select(Doctor)).all()

@app.get("/rooms", response_model=List[Room])
def list_rooms(session: Session = Depends(get_session)):
    return session.exec(select(Room)).all()

# ---------- Appointments ----------
@app.get("/appointments", response_model=List[Appointment])
def list_appointments(
    doctor_id: Optional[int] = None,
    room_id: Optional[int] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
    session: Session = Depends(get_session)
):
    stmt = select(Appointment)
    appts = session.exec(stmt).all()
    def within(a):
        if start and end:
            s = datetime.fromisoformat(start)
            e = datetime.fromisoformat(end)
            return a.start_datetime < e and a.end_datetime > s
        return True
    if doctor_id:
        appts = [a for a in appts if a.doctor_id == doctor_id]
    if room_id:
        appts = [a for a in appts if a.room_id == room_id]
    appts = [a for a in appts if within(a)]
    return appts

@app.post("/appointments", response_model=Appointment)
def create_appointment(appt: Appointment, session: Session = Depends(get_session)):
    # basic overlap check (same doctor or same room)
    overlaps = session.exec(select(Appointment)).all()
    for a in overlaps:
        overlaps_time = appt.start_datetime < a.end_datetime and appt.end_datetime > a.start_datetime
        if overlaps_time and (a.doctor_id == appt.doctor_id or a.room_id == appt.room_id):
            raise HTTPException(400, "Time conflict with another appointment (doctor or room).")
    session.add(appt)
    session.commit()
    session.refresh(appt)
    return appt

@app.put("/appointments/{appt_id}", response_model=Appointment)
def update_appointment(appt_id: int, update: Appointment, session: Session = Depends(get_session)):
    appt = session.get(Appointment, appt_id)
    if not appt: raise HTTPException(404, "Appointment not found")
    for field in ["patient_id","doctor_id","room_id","start_datetime","end_datetime","status","notes"]:
        setattr(appt, field, getattr(update, field))
    # conflict check
    others = session.exec(select(Appointment)).all()
    for a in others:
        if a.id == appt.id: continue
        overlaps_time = appt.start_datetime < a.end_datetime and appt.end_datetime > a.start_datetime
        if overlaps_time and (a.doctor_id == appt.doctor_id or a.room_id == appt.room_id):
            raise HTTPException(400, "Time conflict with another appointment (doctor or room).")
    session.add(appt)
    session.commit()
    session.refresh(appt)
    return appt

@app.delete("/appointments/{appt_id}")
def delete_appointment(appt_id: int, session: Session = Depends(get_session)):
    appt = session.get(Appointment, appt_id)
    if not appt: raise HTTPException(404, "Appointment not found")
    session.delete(appt)
    session.commit()
    return {"ok": True}

# ---------- File Uploads ----------
@app.post("/files/upload", response_model=FileAsset)
async def upload_file(
    patient_id: int = Form(...),
    file: UploadFile = File(...),
    session: Session = Depends(get_session)
):
    patient = session.get(Patient, patient_id)
    if not patient:
        raise HTTPException(404, "Patient not found")
    ext = os.path.splitext(file.filename)[1]
    safe_name = f"{uuid.uuid4().hex}{ext}"
    target = os.path.join(UPLOAD_DIR, safe_name)
    with open(target, "wb") as out:
        shutil.copyfileobj(file.file, out)
    asset = FileAsset(patient_id=patient_id, filename=safe_name, file_type=file.content_type)
    session.add(asset)
    session.commit()
    session.refresh(asset)
    return asset

@app.get("/files/{asset_id}")
def get_file(asset_id: int, session: Session = Depends(get_session)):
    asset = session.get(FileAsset, asset_id)
    if not asset: raise HTTPException(404, "File not found")
    path = os.path.join(UPLOAD_DIR, asset.filename)
    if not os.path.exists(path): raise HTTPException(404, "File missing on disk")
    return FileResponse(path, filename=asset.filename)

# ---------- Dev Seed ----------
@app.post("/dev/seed")
def seed(session: Session = Depends(get_session)):
    # Avoid duplicates
    if not session.exec(select(Doctor)).first():
        doctors = [Doctor(name=f"Dentist {i+1}", specialty="General") for i in range(6)]
        for d in doctors: session.add(d)
    if not session.exec(select(Room)).first():
        rooms = [Room(name=f"Room {i+1}") for i in range(3)]
        for r in rooms: session.add(r)
    session.commit()
    return {"ok": True}
