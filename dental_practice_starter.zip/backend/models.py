from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field, Relationship

class Patient(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    first_name: str
    last_name: str
    dob: Optional[datetime] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    allergies: Optional[str] = None
    conditions: Optional[str] = None
    notes: Optional[str] = None
    consent_signed: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)

    files: list["FileAsset"] = Relationship(back_populates="patient")
    appointments: list["Appointment"] = Relationship(back_populates="patient")

class Doctor(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    specialty: Optional[str] = None
    email: Optional[str] = None

    appointments: list["Appointment"] = Relationship(back_populates="doctor")

class Room(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str

    appointments: list["Appointment"] = Relationship(back_populates="room")

class Appointment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    patient_id: int = Field(foreign_key="patient.id")
    doctor_id: int = Field(foreign_key="doctor.id")
    room_id: int = Field(foreign_key="room.id")
    start_datetime: datetime
    end_datetime: datetime
    status: str = "scheduled"
    notes: Optional[str] = None

    patient: Optional[Patient] = Relationship(back_populates="appointments")
    doctor: Optional[Doctor] = Relationship(back_populates="appointments")
    room: Optional[Room] = Relationship(back_populates="appointments")

class FileAsset(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    patient_id: int = Field(foreign_key="patient.id")
    filename: str
    file_type: Optional[str] = None
    uploaded_at: datetime = Field(default_factory=datetime.utcnow)

    patient: Optional[Patient] = Relationship(back_populates="files")
