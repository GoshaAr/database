# Dental Practice Starter (FastAPI + SQLModel + Vanilla JS)

A minimal starter to manage patients, doctors, rooms, appointments, and file uploads (x‑rays/scans).  
**For demo/dev use**. Harden and extend before using with real patient data.

## Features
- Patients CRUD (basic)
- Doctors and Rooms (seeded)
- Appointments with doctor + room + time window
- File upload per patient (stores on disk, metadata in DB)
- Simple weekly calendar (FullCalendar) to view and create appointments

## Quick Start

1) Create and activate a virtual environment (Python 3.10+ recommended)

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

2) Run the API

```bash
uvicorn backend.main:app --reload
```

- API docs: http://127.0.0.1:8000/docs
- Frontend: open `frontend/index.html` in your browser (or serve from any static server)
  - If your browser blocks local file XHR, run a simple static server:
    ```bash
    python -m http.server 8080 -d frontend
    ```
    Then open http://127.0.0.1:8080

3) (Optional) Seed demo data

```bash
curl -X POST http://127.0.0.1:8000/dev/seed
```

## Notes & Next Steps (Very Important for Real Use)

- **Security/Privacy**: Add auth (e.g., OAuth2 + RBAC). Use HTTPS. Enforce strict CORS. Configure backups, audit logs, and encryption at rest.
- **GDPR/Health Data**: Host PHI on your internal server (on‑prem). Limit internet exposure. Keep scheduling public if needed, but proxy through a secure API gateway/VPN and **never** expose PHI in the public UI.
- **X‑rays/DICOM**: This starter saves files to disk. For real dental x‑rays, integrate a DICOM server such as **Orthanc** and store only references in this DB.
- **Calendar**: We use the free FullCalendar build. Resource timelines (per‑room columns) require a premium license.
- **Scaling**: Move from SQLite to PostgreSQL. Put Nginx in front. Add tests and CI.
